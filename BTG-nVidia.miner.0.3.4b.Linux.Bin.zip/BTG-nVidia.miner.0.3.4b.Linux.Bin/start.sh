./miner --server eu.btgpool.pro --port 3857 --user GLHraJJfsNknm5wGCqSJ7V6cGDnA6gAV8y.worker --pass x  --pec
